package org.infinite.main;

import java.util.List;
import java.util.logging.Logger;

import org.apache.log4j.BasicConfigurator;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.infinite.daohelper.DaoHelper;
import org.infinite.interfaces.IProduct;
import org.infinite.pojo.Product;

public class Implementation implements IProduct {
	static Session sessionObj;
	static SessionFactory sessionFactoryObj;

	public List<Product> displayRecords() {
		// TODO Auto-generated method stub
		List<Product> ls = null;
		String msg = null;
		try {
			BasicConfigurator.configure();
			sessionObj = DaoHelper.buildSessionFactory().openSession();
			Transaction tx = sessionObj.beginTransaction();
			Query q = sessionObj.createQuery("from Products");
			ls = q.list();
			tx.commit();
		} catch (HibernateException e) {
			e.printStackTrace();
		} finally {
			// Close hibernate session.
			sessionObj.close();
		}
		return ls;
	}

	public void insertRecords(String product, int price, int quantity) {
		// TODO Auto-generated method stub
		// Getting Session Object From SessionFactory
		try {
			sessionObj = DaoHelper.buildSessionFactory().openSession();
			// Getting Transaction Object From Session Object
			sessionObj.beginTransaction();
			Product pd = new Product();
			pd.setProduct(product);
			pd.setPrice(price);
			pd.setQuantity(quantity);
			sessionObj.save(pd);
			sessionObj.getTransaction().commit();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			sessionObj.close();
		}
	}

	public void deleteRecords(int id) {
		// TODO Auto-generated method stub
		try {
			sessionObj = DaoHelper.buildSessionFactory().openSession();
			// Getting Transaction Object From Session Object
			sessionObj.beginTransaction();
			Product pd = (Product) sessionObj.load(Product.class, id);
			pd.setId(id);

			sessionObj.delete(pd);
			// logger.info("Deleted");
			sessionObj.getTransaction().commit();
		} catch (Exception sqlException) {
			if (null != sessionObj.getTransaction()) {

				sessionObj.getTransaction().rollback();
			}
			sqlException.printStackTrace();
		} finally {
			if (sessionObj != null) {
				sessionObj.close();
			}
		}

	}

	public void insertRecords() {
		// TODO Auto-generated method stub

	}

	public void deleteRecords() {
		// TODO Auto-generated method stub

	}

}