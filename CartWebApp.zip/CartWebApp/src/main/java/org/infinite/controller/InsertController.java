package org.infinite.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.infinite.main.Implementation;
import org.infinite.pojo.Product;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class InsertController {
	//insert controller for inserting data
	@RequestMapping(value = "/insert", method = RequestMethod.POST)
	public String display(HttpServletRequest request, HttpServletResponse response, Model m) {
		Implementation impl = new Implementation();
		impl.insertRecords();
		return "index";
	}
}
