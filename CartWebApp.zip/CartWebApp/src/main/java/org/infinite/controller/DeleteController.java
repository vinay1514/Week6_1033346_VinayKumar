package org.infinite.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.infinite.main.Implementation;
import org.infinite.pojo.Product;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class DeleteController {
	//delete controller for deleting data
	@RequestMapping(value = "/delete", method = RequestMethod.POST)
	public String display(HttpServletRequest request, HttpServletResponse response, Model m) {
		Implementation impl = new Implementation();
		impl.deleteRecords();
		return "index";
	}
}