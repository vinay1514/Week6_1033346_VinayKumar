package org.infinite.interfaces;

import java.util.List;

import org.infinite.pojo.Product;

public interface IProduct {
	//methods for using
	public List<Product> displayRecords();

	public void insertRecords();

	public void deleteRecords();
}
